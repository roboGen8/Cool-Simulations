#Server/Intersection size which means how many cars can be in intersection:
# server10 = 30 #doesn't matter cus time starts from here
# server11 = 25
# server12 = 25
# server13 = 20
# server14 = 30

from10to11 = 56
from11to12 = 57
from12to13 = 59
from13to14 = 60




east10 = [8, 1.8, 1.8, 30, 3.8, 55]
west10 = [5, 3.6, 4.2, 28, 3.8, 55]
north10 = [7, 3.6, 2.2, 34.7, 3.6, 49.3]
south10 = [7, 3.6, 2.2, 34.7, 3.6, 49.3]

east11 = [0, 0, 0, 20.2, 3.6, 76.1]
west11 = [0, 0, 0, 20.3, 3.6, 76.2]
north11 = [0, 0, 0, 41.5, 3.2, 55.4]
south11 = [0, 0, 0, 41.5, 3.2, 55.4]

east12 = [0, 0, 0, 27.3, 3.6, 69.2]
west12 = [0, 0, 0, 27.3, 3.6, 69.2]
north12 = [0, 0, 0, 60.9, 3.2, 35.7]
south12 = [0, 0, 0, 61.4, 3.2, 35.7]

east13 = [0, 0, 0, 0, 0, 0]
west13 = [0, 0, 0, 0, 0, 0]
north13 = [0, 0, 0, 0, 0, 0]
south13 = [0, 0, 0, 0, 0, 0]

east14 = [9.8, 3.6, 87, 36.9, 3.7, 60.2]
west14 = [0, 0, 0, 22.4, 3.7, 74]
north14 = [8.8, 3.6, 3.6, 34.6, 3.2, 46.1]
south14 = [11.6, 3.6, 0.5, 36.6, 3.2, 45.3]
