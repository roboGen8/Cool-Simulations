while in101[len(in101) - 1] < 900:
    Beta = 6.4713
    r = np.random.exponential(scale=Beta)
    in101.append(r+in101[len(in101)-1])
while in102[len(in102) - 1] < 900:
    Beta = 19.9887
    r = np.random.exponential(scale=Beta)
    in102.append(r+in102[len(in102)-1])
while in123[len(in123) - 1] < 900:
    Beta = 19.9887
    r = np.random.exponential(scale=Beta)
    in123.append(r+in123[len(in123)-1])
while in112[len(in112) - 1] < 900:
    Beta = 85.7611
    r = np.random.exponential(scale=Beta)
    in112.append(r+in112[len(in112)-1])
while in106[len(in106) - 1] < 900:
    Beta = 85.7611
    r = np.random.exponential(scale=Beta)
    in106.append(r+in106[len(in106)-1])
while in103[len(in103) - 1] < 900:
    Beta = 85.7611
    r = np.random.exponential(scale=Beta)
    in103.append(r+in103[len(in103)-1])
