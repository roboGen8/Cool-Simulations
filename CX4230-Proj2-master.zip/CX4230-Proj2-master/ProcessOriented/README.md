Dependencies:
* matplotlib python library: used for output visualizations
* numpy python library: used for statistical functions
* pandas python library: used for processing csv file in empirical data analysis (Not used in simulator)
* scipy python library: used for statistics functions in empirical data analysis (Not used in simulator)

How to Run:
* Adjust input parameters in constants.py to configure simulation to needs
* Run simulator.py in PYTHON 3
